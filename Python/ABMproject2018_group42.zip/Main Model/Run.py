from sugarscape.server import server


server.launch()

