# run.py
from ClubLife_no_walls.server import server

server.port = 8528  # The default
server.launch()
