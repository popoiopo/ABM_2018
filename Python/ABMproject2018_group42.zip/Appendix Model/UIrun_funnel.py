# run.py
from ClubLife.server import server

server.port = 8528  # The default
server.launch()
